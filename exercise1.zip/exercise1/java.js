const generateButton = document.getElementById('generateButton');
        const resetButton = document.getElementById('resetButton');
        const spellArea = document.getElementById('spellArea');
        const ingredientsList = document.getElementById('ingredientsList');
        const ingredients = Array.from(ingredientsList.children).map(li => li.textContent);
        function getRandomColor() {
            const letters = '0123456789ABCDEF';
            let color = '#';
            for (let i = 0; i < 6; i++) {
                color += letters[Math.floor(Math.random() * 16)];
            }
            return color;
        }
        function displayCountdownAndSpell() {
            let count = 3;
            spellArea.innerHTML = `<div class="countdown">${count}</div>`;
            spellArea.style.backgroundColor = '#69e97cff';
            const countdownInterval = setInterval(() => {
                count--;
                if (count > 0) {
                    spellArea.innerHTML = `<div class="countdown">${count}</div>`;
                } else {
                    clearInterval(countdownInterval);
                    const randomIngredient = ingredients[Math.floor(Math.random() * ingredients.length)];
                    spellArea.innerHTML = `<div class="spell-text">Your magical spell uses: ${randomIngredient}!</div>`;
                    spellArea.style.backgroundColor = getRandomColor();
                }
            }, 1000);
        }
        generateButton.addEventListener('click', displayCountdownAndSpell);
        resetButton.addEventListener('click', function() {
            spellArea.innerHTML = 'Your spell will appear here...';
            spellArea.style.backgroundColor = '';
        });







